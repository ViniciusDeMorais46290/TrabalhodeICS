<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>OTARIOS QUE CAIRAM NA MINHA</h1>

    <ul>
        <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <div>
                    <a href="/otarios/<?php echo e($usuario->id); ?>/detalhes"><?php echo e($usuario->Nome); ?></a>
                </div>
            </li>   
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</body>
</html><?php /**PATH /home/vinicius/Desktop/ProjetoHackeandoCartoes/naoefake.net/resources/views/usuarios/index.blade.php ENDPATH**/ ?>