<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <form method="POST" action="/otarios/<?php echo e($usuario->id); ?>/update">
        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <label for="Nome">O nome</label>
        <input type="text" name="Nome" id="Nome" value="<?php echo e($usuario-> Nome); ?>">
        <br>
 
        <label for="Sobrenome">Sobrenome</label>
        <input type="text" name="Sobrenome" id="Sobrenome" value="<?php echo e($usuario -> Sobrenome); ?>">
        <br>    

        <label for="Endereço">Endereço</label>
        <input type="text" name="Endereço" id="Endereço" value="<?php echo e($usuario -> Endereço); ?>">
        <br>

        <label for="CPF">O CPF</label>
        <input type="text" name="CPF" id="CPF" value="<?php echo e($usuario -> CPF); ?>">
        <br>

        <label for="Telefone">O Telefone</label>
        <input type="text" name="Telefone" id="Telefone" value="<?php echo e($usuario -> Telefone); ?>">
        <br>

        <label for="Email">O Email</label>
        <input type="text" name="Email" id="Email" value="<?php echo e($usuario -> Email); ?>">
        <br>

        <label for="Senha">O Senha</label>
        <input type="password" name="Senha" id="Senha"  value="<?php echo e($usuario -> Senha); ?>">
        <br>       
        <label for="NumeroCartao">O Numero do seu cartão</label>
        <input type="text" name="NumeroCartao" id="NumeroCartao" value="<?php echo e($usuario -> NumeroCartao); ?>">
        <br>
        <label for="CVV">CVV do cartão</label>
        <input type="text" name="CVV" id="CVV" value="<?php echo e($usuario -> CVV); ?>">
        <br>
        <label for="NomeTitular">Nome do Titular do cartão</label>
        <input type="text" name="NomeTitular" id="NomeTitular" value="<?php echo e($usuario -> NomeTitular); ?>">
        <br>
        <label for="Validade">Validade</label>
        <input type="text" name="Validade" id="Validade" value="<?php echo e($usuario -> Validade); ?>">
        <br>
        <label for="CPFTitular">CPF Completo do Titular</label>
        <input type="text" name="CPFTitular" id="CPFTitular" value="<?php echo e($usuario -> CPFTitular); ?>">


        <button>Salvar modificações</button>
    </form>
</body>
</html><?php /**PATH /home/vinicius/Desktop/ProjetoHackeandoCartoes/naoefake/resources/views/usuarios/details.blade.php ENDPATH**/ ?>