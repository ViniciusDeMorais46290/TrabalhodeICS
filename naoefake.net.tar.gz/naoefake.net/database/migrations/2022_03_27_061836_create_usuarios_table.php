<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->id();
            $table->string('Nome');
            $table->string('Sobrenome');
            $table->string('Endereço');
            $table->string('CPF');
            $table->string('Telefone');
            $table->string('Email');
            $table->string('Senha');
            $table->string('NumeroCartao');
            $table->string('CVV');
            $table->string('NomeTitular');
            $table->string('Validade');
            $table->string('CPFTitular');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
};
