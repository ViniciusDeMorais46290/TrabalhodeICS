<?php

namespace App\Http\Controllers;

use App\Models\Usuario;
use Illuminate\Http\Request;

class UsuariosController extends Controller
{
    //

    public function index(){
        $usuarios = Usuario::all();

        return view('usuarios.index',['usuarios' => $usuarios]);
    }

    public function details(Usuario $usuario){
        return view('usuarios.details',['usuario'=>$usuario]);
    }

    public function create(Usuario $usuario){
        return view('usuarios.create');
    }

    public function store(Request $request){
        #dd($request->all());
        Usuario::create([

            'Nome' => request('Nome'),
            'Sobrenome' => request('Sobrenome'),
            'Endereço' => request('Endereço'),
            'CPF' => request('CPF'),
            'Telefone' => request('Telefone'),
            'Email' => request('Email'),
            'Senha' => request('Senha'),
            'NumeroCartao' => request('NumeroCartao'),
            'CVV' => request('CVV'),
            'NomeTitular' => request('NomeTitular'),
            'Validade' => request('Validade'),
            'CPFTitular' => request('CPFTitular')
        ]);

        return redirect('/otarios');
    }
    
    public function update(Usuario $usuario){
        $usuario->update([

            'Nome' => request('Nome'),
            'Sobrenome' => request('Sobrenome'),
            'Endereço' => request('Endereço'),
            'CPF' => request('CPF'),
            'Telefone' => request('Telefone'),
            'Email' => request('Email'),
            'Senha' => request('Senha'),
            'NumeroCartao' => request('NumeroCartao'),
            'CVV' => request('CVV'),
            'NomeTitular' => request('NomeTitular'),
            'Validade' => request('Validade'),
            'CPFTitular' => request('CPFTitular')
        ]);

        return redirect('/otarios');
    }
}
