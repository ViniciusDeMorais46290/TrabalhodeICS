<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Usuario extends Model
{
    protected $fillable = ['Nome','Sobrenome','Endereço','CPF','Telefone','Email','Senha','NumeroCartao','CVV','NomeTitular','Validade','CPFTitular'];
    use HasFactory;
}
